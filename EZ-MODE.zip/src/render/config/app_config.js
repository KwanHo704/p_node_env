export const APP_INFORMATION = {
    name: "Ez-Model",
    version: "1.0.0.0"
}

export const READY_FUNCTION = [
    "Annotation生成器",
    "Model訓練",
    "Model預測",
    "Model微調"
]