import face_recognition
import numpy as np
import cv2
import os
import base64
from PIL import Image
import io


ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
FACE_DIR = os.path.join(ROOT_DIR,"faces")

class FaceDetector:
    def __init__(self) -> None:
        faces = dict()
        isInit = False
        pass

    def initialize(self):
        faces = dict()

        if os.path.exists(FACE_DIR) and os.path.isdir(FACE_DIR):
            for f in os.listdir(FACE_DIR):
                if f.split(".")[-1] in ["jpg","jpeg","png"]:
                    name  = "".join(f.split(".")[:-1])
                    path = os.path.join(FACE_DIR,f)
                    face = face_recognition.load_image_file(path)
                    face = cv2.cvtColor(face,cv2.COLOR_BGR2RGB)
                    face_location = face_recognition.face_locations(face)[0]
                    face_encoding = face_recognition.face_encodings(face)[0]
                    faces[str(name)] = [face_encoding,face_location]
                    
        self.faces = faces
        self.isInit = True
    
    def recongnition(self,image):
        face_locations = []
        face_encodings = []
        face_names = []
        
        small = cv2.resize(image,(0,0),fx=0.25,fy=0.25)
        rgb = small[:,:,::-1]

        face_locations = face_recognition.face_locations(rgb)
        face_encodings = face_recognition.face_encodings(rgb,face_locations)

        for face_encoding in face_encodings:
            matches = face_recognition.compare_faces(list(self.faces.values()),face_encoding)
            name = "Unknown"

            face_distances = face_recognition.face_distance(list(self.faces.values()),face_encodings)
            index = np.argmin(face_distances)
            if matches[index]:
                name = list(self.faces.keys())[index]

            if name not in face_names:
                face_names.append(name)

        return face_names

    def compareFace(self,image,useranem):
        
        faces = self.getFace(useranem)

        if not len(faces) > 0:
            return False
        
        face = np.fromstring(base64.b64decode(image.split(",")[1]),np.uint8)
        face = cv2.imdecode(face,cv2.IMREAD_UNCHANGED)
        gray = cv2.cvtColor(face,cv2.COLOR_BGR2GRAY)

        
        print("here")
        print("here")
        face_locations = face_recognition.face_locations(face)
        
        print("here")
        print(len(face_locations))
        cv2.imwrite("output.jpg",gray)
        face_encodings = face_recognition.face_encodings(face,face_locations)
        
        print("here")
        print(len(face_encodings))

        
        for item in face_encodings:
            print(item.shape)


            matches = face_recognition.compare_faces(faces,item,0.7)
            name = "Unknown"


            face_distances = face_recognition.face_distance(faces,item)
            index = np.argmin(face_distances)
            if matches[index]:
                name = list(self.faces.keys())[index]
                return True 

        return False

    def getFace(self,username):
        faces = []
        for i in self.faces.keys():
            if i == username:
                faces.append(self.faces[i][0])

        return faces