from email import message
import eventlet
eventlet.monkey_patch()
from flask import Flask,request
from flask_cors import CORS
from flask_socketio import SocketIO,emit,join_room,leave_room
# from face import FaceDetector
from googletrans import Translator
from face import FaceDetector

import threading
from threading import Lock

app = Flask(__name__)
socketio = SocketIO(app,cors_allowed_origins='*')
CORS(app)

thread =None
thread_lock = Lock()

translator = Translator()


faceDetector = FaceDetector()
faceDetector.initialize()


@socketio.on("join-room")
def on_join(data):
    room = data["room"]
    username = data["username"]
    join_room(room)
    print('RoomEvent: {} has joined the room {}\n'.format(username, room))
    socketio.emit('on_message', {"username": username,"message":"Joined Room ! Welcome ~","room":room},to=room)

@socketio.on("leave-room")
def on_leave(data):
    room = data["room"]
    username = data["username"]
    leave_room(room)
    print('RoomEvent: {} has leave the room {}\n'.format(username, room))
    emit('on_leave', {room: room},to=room)
    

@socketio.on("transcription")
def on_transcription(data):
    room = data["room"]
    transcript = data["transcript"]
    isFinal = data["isFinal"]
    emit('on_transcription', {"transcript": transcript,"isFinal": isFinal}, to=room)
    
    socketio.sleep()

@socketio.on("translate")
def on_translate(data):
    transcript = data["transcript"]
    lang = data["lang"]
    print(transcript)
    print(lang)
    global thread
    with thread_lock:
        if thread is None:
            global translator
            translate = translator.translate(transcript,dest=lang)
            emit("on_translate",{"translate":translate.text,"transcript":transcript})

@socketio.on("message")
def on_message(data):
    message = data["message"]
    username = data["username"]
    room = data["room"]
    print(room)
    print(message)
    print(username)
    emit("on_message",{"username":username,"message":message},to=room)
    
@socketio.on("sign")
def on_sign(data):
    room = data["room"]
    username = data["username"]
    face = data["face"]
    global thread
    with thread_lock:
        if thread is None:
            global faceDetector
            done = faceDetector.compareFace(face,username)
            if done:
                emit("on_sign",{"username":username},to=room)


# @socketio.on("event")
# def on_event(data):
#     room = data["room"]
#     event = data["event"]
#     emit("on_event",{"event":event},to=room)

@socketio.on('video')
def on_video(data):
    emit('on_video', {"video":data["video"]}, to=data["room"])
    socketio.sleep()
    

@socketio.on('screen')
def on_screen(data):
    emit('on_screen', {"video":data["video"]}, to=data["room"])
    
    socketio.sleep()

@socketio.on_error_default
def default_error_handler(e):
    print("Error: {}".format(e))
    socketio.stop()

if __name__ == "__main__":
    socketio.run(app,host="0.0.0.0",port=9001,debug=True) 