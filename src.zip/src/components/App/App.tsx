import "./App.scss"
import Sidebar from "../Sidebar/Sidebar";
import MainSection from "../MainSection/MainSection";

const App = () => {
    return(
        <div className="app dark">
            <Sidebar />
            <MainSection />
        </div>
    )
};

export default App;
