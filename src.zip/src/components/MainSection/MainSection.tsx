import "./MainSection.scss";

const MainSection = () => {
    return <div className="main-section">
    </div>;
};

export default MainSection;
