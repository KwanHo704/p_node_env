import "./Sidebar.scss"

const Sidebar = () => {
    return(
        <div className="sidebar">
            <div className="sidebar-header">
                123
            </div>
            <div className="sidebar-content">
                
            </div>
        </div>
    )
};

export default Sidebar;
