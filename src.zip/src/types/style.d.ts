declare module "*.scss";
declare module "*.module.scss";
