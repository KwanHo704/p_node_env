import routes from "../../routes/routes";
import { routesDecode } from "../../utils/routesHandler";
import { HashRouter as Router, Routes } from "react-router-dom";

const MainSection = () => {
    return (
        <div className="main-section">
            <Router>
                <Routes>{routesDecode(routes)}</Routes>
            </Router>
        </div>
    );
};

export default MainSection;
