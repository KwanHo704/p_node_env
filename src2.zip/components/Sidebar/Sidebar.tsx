import "./Sidebar.scss";
import logo from "./logo.png";
import SidebarHeader from "./SidebarHeader";
import SidebarBody from "./SidebarBody";
import SidebarFooter from "./SidebarFooter";

const Sidebar = () => {
    return (
        <div className="sidebar">
            <SidebarHeader />
            <SidebarBody />
            <SidebarFooter />
        </div>
    );
};

export default Sidebar;
