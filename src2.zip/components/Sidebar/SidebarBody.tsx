import routes from "../../routes/routes";

const SidebarBody = () => {
    const menu = {
        ...routes.DASHBOARD,
    };

    console.log(Object.entries(menu));
    return (
        <div className="sidebar-body">
            <ul>
                <li>
                    <span className="material-symbols-outlined icon">dashboard</span>Dashboard
                </li>
                <li>
                    <span className="material-symbols-outlined icon">home_repair_service</span>Module
                </li>
            </ul>
        </div>
    );
};

export default SidebarBody;
