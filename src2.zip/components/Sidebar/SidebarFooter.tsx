const SidebarFooter = () => {
    return (
        <div className="sidebar-footer">
            <ul>
                <li>Logout</li>
            </ul>
        </div>
    );
};

export default SidebarFooter;
