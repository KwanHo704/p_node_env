import logo from "./logo.png";

const SidebarHeader = () => {
    return (
        <div className="sidebar-header">
            <div className="item">
                <img className="logo" src={logo}></img>
                <h2 className="font-op-1">
                    ML<span className="prefix">_Platform</span>
                </h2>
            </div>
        </div>
    );
};

export default SidebarHeader;
