import Dashboard from "./Dashboard";
import DashboardSub from "./DashboardSub";

export const DashboardRoutes = {
    main: {
        path: "dashboard",
        element: <Dashboard />,
    },
    channel: {
        sub: {
            path: "sub",
            element: <DashboardSub />
        },
    },
};
