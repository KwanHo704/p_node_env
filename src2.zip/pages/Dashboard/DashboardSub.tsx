const DashboardSub = () => {
    return <div className="dashboard">DashboardSub</div>;
};

export default DashboardSub;
