import Home from "./Home";

export const HomeRoutes = {
    main:{
        path: "/",
        element: <Home />
    }
}