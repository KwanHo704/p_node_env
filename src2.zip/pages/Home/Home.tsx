import { Navigate } from "react-router-dom"
import routes from "../../routes/routes"

const Home = () => {
    return (
        <>
            <Navigate replace to={routes.DASHBOARD.path} />
        </>
    )
}

export default Home