import { DashboardRoutes } from "../pages/Dashboard/Dashboard.routes"
import { HomeRoutes } from "../pages/Home/Home.routes"

const routes = {
    HOME:{
        path: HomeRoutes.main.path,
        element: HomeRoutes.main.element
    },
    DASHBOARD:{
        path: DashboardRoutes.main.path,
        element: DashboardRoutes.main.element,
        channel:{
            ...DashboardRoutes.channel
        }
    }
}

export default routes