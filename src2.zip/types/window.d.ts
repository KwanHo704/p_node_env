declare global {
    interface Window {
        SpeechRecongition: any;
    }
}
