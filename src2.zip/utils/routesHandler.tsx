import { Route } from "react-router-dom";

export const routesDecode = (routes: any) => {
    return Object.values(routes).map((route: any) => {
        return (
            <Route key={route?.path} path={route?.path}>
                <Route index element={route?.element} />
                {route?.channel ? routesDecode(route.channel) : ""}
            </Route>
        );
    });
};
